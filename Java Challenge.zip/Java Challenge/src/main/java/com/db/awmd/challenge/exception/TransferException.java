package com.db.awmd.challenge.exception;

public class TransferException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = -6548125612019417791L;

	public TransferException(String message) {
		super(message);
	}
	

}
